"use client"
import React, { ReactNode } from 'react';
import { SessionProvider } from "next-auth/react"
/* import { AppProps } from "next/app"
 */
interface ProviderProps {
  children: ReactNode;
}
 const AuthSessionProvWrapper:React.FC<ProviderProps> = ({children})  => {
  return (
    // `session` comes from `getServerSideProps` or `getInitialProps`.
    // Avoids flickering/session loading on first load.
    <SessionProvider>
      {children}
    </SessionProvider>
  )
}

export default  AuthSessionProvWrapper;
