import nodemailer from "nodemailer";
export const sendMail = async (props: { to: string; subject: string; text: string }) => {
  try {
    //const transporter =  newvalue();
    const transporter = nodemailer.createTransport({
      host: "sandbox.smtp.mailtrap.io",
      port: 2525,
      auth: {
        user: "bc3792548d8495",
        pass: "e31c5ee409d6c8",
      },
    });

    const mailOptions = {
      from: "admin-email@gmail.com",
      to: props.to,
      subject: props.subject,
      text: props.text,
    };

    await transporter.sendMail(mailOptions);

    console.log("Email sent successfully!");
    return { success: true, message: "Email sent successfully!" };
  } catch (error) {
    console.error("Error sending email: ", error);
    throw error;
  }
};
