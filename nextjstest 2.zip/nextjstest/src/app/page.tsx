"use client"
import Child from "@/components/child";
import ChildTwo from "@/components/childTwo";
import { createContext, useState } from "react";
// Define the type for the context value
export interface GlobalContextType {
  appColor: string;
  colorHandler: (color: string) => void;
}
// context defind here for color 
// Create the context with the specified type
export const GlobalContext = createContext<GlobalContextType | undefined>(undefined);
    
export default function Home() {
  const [color, setColor] = useState('green');

  function setColorHandler(item:string){
   console.log(item)
    setColor(item)
  } 
  return (
         <>
        {/* Wrap the children components with the context provider */}
        <GlobalContext.Provider value={{ appColor: color , colorHandler:setColorHandler  }} >
          <Child />
          <ChildTwo />
        </GlobalContext.Provider>
        </> 

  );
}
