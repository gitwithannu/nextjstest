import React from 'react'

const page = () => {
  return (
    <>
    <div>Service page </div>
    <h1> Hello value here </h1>
    </>
  )
}

export default page