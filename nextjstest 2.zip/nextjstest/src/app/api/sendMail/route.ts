import { NextRequest, NextResponse } from "next/server";
import { sendMail } from "@/helper/sendMail";
export async function POST(req:NextRequest) {
  // Parse JSON body
  const body = await req.json();
  // Extract data from the request body
  console.log('body mail check ', body)
  if(body.email) { 
    try {
      await sendMail({
        to: body.email,
        subject: "Testmail",
        text: "This is only for testing purposes.",
      });

      console.log("Email sent successfully!");
      return NextResponse.json({ message: "Email sent successfully!" });
    } catch (error) {
      console.error("Error sending email:", error);
      return NextResponse.json(
        { message: "Failed to send email!" },
        { status: 500 }
      );
    }
  }
  return NextResponse.json(
    { message: "Failed to send email. Provide email id!" },
    { status: 500 }
  );
}