import bcrypt from "bcrypt";
import User from "@/models/User";
import { connectDb } from "@/lib/mongoose";
import { NextResponse, NextRequest } from "next/server";

export async function POST(req:NextRequest){

  try {

    const body = await req.json();
    console.log('loging details ',body)
    // Extract data from the request body
    const { email, password } = body;

      // Validate required fields
      if (!email || !password) {
        return NextResponse.json(
          { error: "All fields are required" },
          { status: 400 }
        );    
      }

     await connectDb();

     // find the user with email id

     const user  = await User.findOne({'email':email})
     if(!user){     
        return NextResponse.json(
            { error : "Invalid email and  password" },
            { status: 401 } //// Unauthorized
        )    
     }

     // Compare the provided password with the stored hashed password

     const isPasswordValid  = await bcrypt.compare(password, user.password)
     if(!isPasswordValid){
       return NextResponse.json(
        {error  : " Invalid email and password"},
        {status : 401 } // unauthorized
       )
     }

     // Success Login

     return NextResponse.json(
      {message:"login successful", user:{id: user._id, email:user.email}},
      {status:200} // success
     )

    }
    catch(error){
      console.error("Error in POST /api/login:", error);
      return NextResponse.json(
        {error: "Internal Server Error"},
        {status: 500 }  // Server Error 
      )
    }

}