import Chance from 'chance';
const chance  = Chance ();

const fakeUserData = () => {

   // console.log(" -- Fake data generate  -- ");

 return chance.name({ middle:true }) ;  
}

export default fakeUserData;
 