import NextAuth, { AuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
const BASE_URI = process.env.NEXTAUTH_URL;

export const authOptions: AuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text", placeholder: "your-email@example.com" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials, req) {

        if (!credentials || !credentials.email || !credentials.password ) {
          console.error("Credentials are missing or incomplete.");
          return null;  
        }

        const res = await fetch(BASE_URI+"/api/login", {
          method: 'POST',
          body: JSON.stringify(credentials),  
          headers: { "Content-Type": "application/json" }
        })
        const user = await res.json()
        console.log('============================= user ==============',user);

        // If no error and we have user data, return it
        if (res.ok && user) {
          return user
        }

        return null; // Return null if credentials are invalid 
      },
    }),
  ],
  secret: process.env.NEXTAUTH_SECRET, // Set this in your .env.local file
  session: {
    strategy: "jwt", // Explicitly set to "jwt", which matches the expected type
  },
  pages: {
    signIn: "/auth/signin", // Optional: Custom sign-in page
  },
};

const handler = NextAuth(authOptions);
// export handler with Get 
export { handler as GET, handler as POST };
