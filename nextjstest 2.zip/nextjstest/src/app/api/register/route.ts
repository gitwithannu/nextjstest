import { NextRequest, NextResponse } from "next/server";
import { connectDb } from "@/lib/mongoose";
import logger from "@/lib/logger";
import User from "@/models/User";
import bcrypt from "bcrypt";

// Ensure mongoose is connected
export async function POST(req: NextRequest) {
  try {
    // Parse JSON body
    const body = await req.json();

    // Extract data from the request body
    const { regfname, reglname, regemail, regpassword } = body;

    // Validate required fields
    if (!regfname || !reglname || !regemail || !regpassword) {
      return NextResponse.json(
        { error: "All fields are required" },
        { status: 400 }
      );
    }

    // Ensure database connection
    await connectDb();

    // Check if the user already exists
    const existingUser = await User.findOne({ email: regemail });
    console.log("existingUser:", existingUser);
    console.log("regemail:", regemail);

    if (existingUser) {
      return NextResponse.json(
        { error: "User already exists" },
        { status: 400 }
      );
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(regpassword, 10);

    // Create a new user
    const newUser = new User({
      firstName: regfname,
      lastName: reglname,
      email: regemail,
      password: hashedPassword,
      isActive: true, // New users are active by default
      isAdmin: false, // Default to non-admin if not specified
      role: "user", // Default role is 'user'
      createdOn: new Date(),
      updatedOn: new Date(),
    });

    // Save the user to the database
    const res = await newUser.save();

    if (res._id) {
      try {
        // Send registration email
        const sendReq = await fetch(`${process.env.NEXTAUTH_URL}/api/sendMail`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: res.email,
          }),
        });

        const Mailres = await sendReq.json();
        console.log("Mailres:", Mailres);
      } catch {
        // Log email sending failure
        logger.registration(
          `Error occurred for ${res.email}: Registration mail failed`
        );

        return NextResponse.json(
          { error: "Registration mail failed due to server error" },
          { status: 500 }
        );
      }

      // Return success response
      return NextResponse.json(
        { message: "User registered successfully!" },
        { status: 200 }
      );
    }
  } catch (error) {
    console.error("Error processing request:", error);

    // Return error response
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
