import React from 'react'

const page = () => {
  return (
    
    <div>User sub page . made this for testing. add dummy slug after the slug 
     users/etc.   like this users/a  , users/test      
    </div>
  )
}

export default page