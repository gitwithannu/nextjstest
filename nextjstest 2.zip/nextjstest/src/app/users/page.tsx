"use client"
import UserList from '@/components/UserList'
import React from 'react'
import { useDispatch } from 'react-redux';
import { addUser } from '@/redux/slices/userSlice';
import  fakeUserData  from "@/app/api/fakedata"
const User = () => {
   const dispatch = useDispatch();
    const addUserHandler = () =>{

      dispatch(addUser(fakeUserData()));
      //console.log(fakeUserData());
      //console.log('testing data here');

      console.log('click for add user handler');

    }

  return (
    
    <div className='px-4'>
      <div className='relative mx-auto lg:max-w-7xl'>
      <main className="pb-40 pt-2">
        <div className="relative grid gap-[17px] sm:grid-cols-2 xl:grid-cols-[repeat(15,_minmax(0,_1fr))]">
          <h1> users </h1>
        </div>
        <div className="relative sm:col-span-2 xl:col-span-9"></div>
      </main>
      <div className="relative h-full w-full rounded-xl bg-white shadow-[0px_0px_0px_1px_rgba(9,9,11,0.07),0px_2px_2px_0px_rgba(9,9,11,0.05)] dark:bg-zinc-900 dark:shadow-[0px_0px_0px_1px_rgba(255,255,255,0.1)] dark:before:pointer-events-none dark:before:absolute dark:before:-inset-px dark:before:rounded-xl dark:before:shadow-[0px_2px_8px_0px_rgba(0,_0,_0,_0.20),_0px_1px_0px_0px_rgba(255,_255,_255,_0.06)_inset] forced-colors:outline">
      <button className='px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-blue-600  float-right'> Delete All User  </button>
      <button onClick={ ()=>addUserHandler() } className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300 float-right"> Add User </button>
       
        <UserList />

        </div>

      </div>
    </div>
  )
}

export default User