"use client";

import { useSession, signIn } from "next-auth/react";

export default function ProtectedPage() {
  const { data: session, status } = useSession();

  if (status === "loading") return <p>Loading...</p>;

  if (!session) {
    return (
      <div>
        <p>You need to sign in to access this page.</p>
        <button onClick={() => signIn()}>Sign In</button>
      </div>
    );
  }
  return (
    <div>
      <h1>Welcome, {session.user.name}</h1>
      <p>This is a protected page.</p>
    </div>
  );
}
