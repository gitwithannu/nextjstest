"use client";
import React from "react";
import { useSession, signIn, signOut } from "next-auth/react"
import Link from "next/link";
  const LoginLogout =  () => {
  const { data: session, status } = useSession()
  if (status === "loading") {
    return "Loading or not authenticated..."
  }
  if (session) {    
    return (
      <>
         <li> Signed in as {session?.user?.email} <br></br>   </li>
         <li> <button className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-400 focus:outline-none focus:ring focus:ring-blue-300" onClick={() => signOut()}>Sign out</button></li>
         <li><img className="w-8 h-8 rounded-full" alt="user photo" src="https://flowbite.com/docs/images/people/profile-picture-3.jpg"/></li>

        
      </>
    )
  }
  return (
    <>
      <li>
      <Link href="/auth/signin">
        <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-400 focus:outline-none focus:ring focus:ring-blue-300" >Sign in</button>
        </Link>
        </li>
        
      <li>
        <Link href="/register">
        <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-400 focus:outline-none focus:ring focus:ring-blue-300"  >Regiser</button>
        </Link>
        </li>
    </>
  )
}
export default LoginLogout;