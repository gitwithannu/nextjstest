"use client"
import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { deleteUser } from '@/redux/slices/userSlice'

interface User {
    name: string; // Adjust this based on the structure of your user object
  }
  

const UserList = () => {
    const dispatch  = useDispatch();
    
    const deletUserHandler = (id:number) =>{
        dispatch(deleteUser(id))
    }
    const users  = useSelector((state:{ users: User[] })=> {
       return state.users ;
    });
    
    console.log('users',users);

  return (
    <div className='mt-10 w-98' >
      <h1 className='mb-2'> User List herer</h1>
      <ul>
       {
        users && users.length > 0 ? (
          users.map((item, index)=>(
            <li className='mt-4' key={index}> 
            <div className='w-80 bg-yellow-500  float-left  '>  { item } </div>
             <button className=' px-4  bg-red-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300  ml-40' onClick={()=>deletUserHandler(index)}>X</button> </li>
          ))
        ) :(
            <p> No user data Availble   </p>
        )
        
       }
      </ul>
    </div>
  )
}

export default UserList