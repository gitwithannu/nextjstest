import React from 'react'

const RegisterComp = () => {

  const handleButtonClick = () => {
    // Call the parent's function and send data
    onDataUpdate("Hello from the Child Component!");
  };
  
  return (
    <div>Register Components </div>
  )
}

export default RegisterComp;