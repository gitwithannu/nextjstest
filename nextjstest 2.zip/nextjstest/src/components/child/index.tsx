import React, { useContext } from 'react'
import { GlobalContext } from '@/app/page'



function Child() {


  const context = useContext(GlobalContext) ;
  if (!context) {
    throw new Error("GlobalContext must be used within a GlobalContext.Provider");
  }
  const {  appColor , colorHandler } = context ;
  return (
    <>
    <div><h1 style={{color:appColor}}>child  one test : {appColor} </h1> </div>

    <button onClick={() => colorHandler('gray')} className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into gray </button>

    <button onClick={() => colorHandler('lime')} className="px-4 py-2 bg-lime-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into lime </button>

    <button onClick={() => colorHandler('orange')} className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into orange </button>

    <button onClick={() => colorHandler('rose')} className="px-4 py-2 bg-rose-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into rose </button>
    </>
  )
}

export default Child