import React, { useContext } from 'react'
import { GlobalContext } from '@/app/page';


 
function ChildTwo() {
    const context = useContext(GlobalContext);
     if (!context) {
        throw new Error("GlobalContext must be used within a GlobalContext.Provider");
      }
    const {  appColor , colorHandler } = context;
  return (<>
        <h2 style={{color:appColor}}> Child components Two index  : {appColor} </h2>
        
        <button onClick={() => colorHandler('blue')} className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into blue </button>

        <button onClick={() => colorHandler('yellow')} className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into yellow </button>

        <button onClick={() => colorHandler('red')} className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into Red </button>

        <button onClick={() => colorHandler('purple')} className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300"> Change Color into purple </button>

        <button onClick={ () => colorHandler('orange') } className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring focus:ring-blue-300" > nto orange </button>

     </>
  )
}

export default ChildTwo