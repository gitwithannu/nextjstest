import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice ({
    name : 'users',
    initialState :[],
    reducers: {
        addUser : (state, action)=>{
            console.log('call to add user Reducer ');
            state.push(action.payload)
        },
        deleteUser :(state,action)=>{
         state.splice(action.payload,1)
        },
        deleteAll: (state,action) => {
          state();
        }
    }
})  

export const  { addUser , deleteUser }  = userSlice.actions;
export default userSlice.reducer;