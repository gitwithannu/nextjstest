
import { withAuth } from "next-auth/middleware";

export default withAuth({
  pages: {
    signIn: "/auth/signin",
  },
});

export const config = {
  matcher: ["/protected/:path*"], // Protect specific routes
};



/* import { NextResponse } from "next/server";

export function middleware(request){
    // static condition here tests modify the request here
    // if(request.nextUrl.pathname !=='/login'){
     return NextResponse.redirect( new URL('/login',request.url))
  //  }
}

export const config = {
    matcher: ['/users/:path/:path+', '/test/:path*']
} */